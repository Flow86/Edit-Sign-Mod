Editable Signs
-------------------------------------------------------------------------------

Current Version 1.2

for Minecraft 1.0.0

Depends on: ModLoader

-------------------------------------------------------------------------------

simply adds the possibility to Signs to edit the Sign.

Everything without changing one line of code in the original minecraft.jar

-----------------------------

Changelog:

1.2 - Update
- updated for Minecraft 1.0.0
- added license

1.8.1b_2 - Fix
- fixed signPost/signWall Obfuscation

1.8.1b - Initial
- overwrite BlockSign with BlockEditableSign

-------------------------------------------------------------------------------

